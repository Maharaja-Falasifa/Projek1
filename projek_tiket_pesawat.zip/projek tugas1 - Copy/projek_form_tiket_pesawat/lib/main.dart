import 'package:flutter/material.dart';

void main() {
  runApp(const TiketPesawatApp());
}

class TiketPesawatApp extends StatelessWidget {
  const TiketPesawatApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Web Form Pemesanan Tiket Pesawat',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 83, 0, 108)),
        useMaterial3: true,
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
      home: const FormPemesananTiketPage(),
    );
  }
}

class FormPemesananTiketPage extends StatefulWidget {
  const FormPemesananTiketPage({super.key});

  @override
  State<FormPemesananTiketPage> createState() => _FormPemesananTiketPageState();
}

class _FormPemesananTiketPageState extends State<FormPemesananTiketPage> {
  // 1. GlobalKey untuk mengelola dan memvalidasi form[cite: 6]
  final _formKey = GlobalKey<FormState>();

  // 2. Controllers untuk Input Teks[cite: 6]
  final _namaPemesanController = TextEditingController();
  final _teleponController = TextEditingController();
  final _emailController = TextEditingController();
  
  final _namaDepanPenumpangController = TextEditingController();
  final _namaBelakangPenumpangController = TextEditingController();
  final _nomorIdentitasController = TextEditingController();
  
  final _tanggalBerangkatController = TextEditingController();
  final _tanggalKepulanganController = TextEditingController();

  // 3. State Pilihan (Selection & Radio & Dropdown)[cite: 5, 13, 14]
  String _jenisPerjalanan = 'Sekali jalan';
  String? _kotaAsal;
  String? _kotaTujuan;
  String? _maskapaiTerpilih;
  String _JenisKelamin = 'Laki-Laki';
  String _kelasKursi = 'Economy';
  String _metodePembayaran = 'Transfer Bank';

  // State Jumlah Penumpang
  int _jumlahDewasa = 1;
  int _jumlahAnak = 0;
  int _jumlahBayi = 0;

  // State Checkbox Fasilitas Tambahan (Banyak Opsi)[cite: 12]
  final Map<String, bool> _fasilitasTambahan = {
    'Bagasi Ekstra 20kg': false,
    'Makanan In-Flight': false,
    'Asuransi Perjalanan': false,
    'Pilih Kursi Jendela': false,
  };

  // State Checkbox Syarat & Ketentuan[cite: 19]
  bool _setujuSyarat = false;

  final List<String> _daftarKota = [
    'Bandara Soekarno-Hatta - CGK (Jakarta)',
    'Bandara I Gusti Ngurah Rai - DPS (Bali)',
    'Bandara Juanda - SUB (Surabaya)',
    'Bandara Kualanamu - KNO (Medan)',
    'Bandara Sultan Hasanuddin - UGJ (Makassar)',
  ];

  final List<String> _daftarMaskapai = [
    'Garuda Indonesia',
    'Citilink',
    'Batik Air',
    'Lion Air',
    'AirAsia',
  ];

  @override
  void dispose() {
    _namaPemesanController.dispose();
    _teleponController.dispose();
    _emailController.dispose();
    _namaDepanPenumpangController.dispose();
    _namaBelakangPenumpangController.dispose();
    _nomorIdentitasController.dispose();
    _tanggalBerangkatController.dispose();
    _tanggalKepulanganController.dispose();
    super.dispose();
  }

  // Fungsi Date Picker[cite: 11]
  Future<void> _pilihTanggal(BuildContext context, TextEditingController controller) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 1)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
    );
    if (picked != null) {
      setState(() {
        controller.text = '${picked.day.toString().padLeft(2, '0')}/${picked.month.toString().padLeft(2, '0')}/${picked.year}';
      });
    }
  }

  // Fungsi Proses & Validasi Form[cite: 17, 19]
  void _prosesPemesanan() {
    if (_formKey.currentState!.validate()) {
      if (!_setujuSyarat) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Anda harus menyetujui syarat dan ketentuan pemesanan tiket!'),
            backgroundColor: Colors.redAccent,
          ),
        );
        return;
      }

      // Ambil daftar fasilitas yang dicentang
      final fasilitasDipilih = _fasilitasTambahan.entries
          .where((e) => e.value)
          .map((e) => e.key)
          .toList();

      // Tampilkan Dialog Ringkasan Data[cite: 19]
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.airplane_ticket, color: Color.fromARGB(255, 83, 0, 108)),
              SizedBox(width: 10),
              Text('Ringkasan E-Tiket Pesawat'),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildInfoRow('Jenis Perjalanan', _jenisPerjalanan),
                _buildInfoRow('Rute', '${_kotaAsal ?? "-"} ➔ ${_kotaTujuan ?? "-"}'),
                _buildInfoRow('Tgl Keberangkatan', _tanggalBerangkatController.text),
                if (_jenisPerjalanan == 'Pulang-pergi')
                  _buildInfoRow('Tgl Kepulangan', _tanggalKepulanganController.text),
                _buildInfoRow('Jumlah Penumpang', 'Dewasa: $_jumlahDewasa, Anak: $_jumlahAnak, Bayi: $_jumlahBayi'),
                _buildInfoRow('Pemesan', '${_namaPemesanController.text} (${_teleponController.text})'),
                _buildInfoRow('Email E-Tiket', _emailController.text),
                _buildInfoRow('Penumpang', '$_JenisKelamin. ${_namaDepanPenumpangController.text} ${_namaBelakangPenumpangController.text}'),
                _buildInfoRow('No Identitas (KTP/Paspor)', _nomorIdentitasController.text),
                _buildInfoRow('Maskapai & Kelas', '${_maskapaiTerpilih ?? "-"} - $_kelasKursi'),
                _buildInfoRow('Fasilitas Tambahan', fasilitasDipilih.isEmpty ? 'Tidak ada' : fasilitasDipilih.join(', ')),
                _buildInfoRow('Metode Pembayaran', _metodePembayaran),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Tutup'),
            ),
            FilledButton(
              onPressed: () {
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Pemesanan tiket berhasil diproses! Silakan lakukan pembayaran.'),
                    backgroundColor: Colors.green,
                  ),
                );
              },
              child: const Text('Konfirmasi & Bayar'),
            ),
          ],
        ),
      );
    }
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: RichText(
        text: TextSpan(
          style: const TextStyle(color: Colors.black87, fontSize: 13),
          children: [
            TextSpan(text: '$label: ', style: const TextStyle(fontWeight: FontWeight.bold)),
            TextSpan(text: value),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text(
          'Pemesanan Tiket Pesawat Online',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 83, 0, 108),
        centerTitle: true,
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 700),
            child: Card(
              elevation: 4,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Formulir Pemesanan Penerbangan',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color.fromARGB(255, 83, 0, 108)),
                      ),
                      const SizedBox(height: 4),
                      const Text(
                        'Lengkapi informasi perjalanan, data kontak, dan identitas penumpang dengan benar.',
                        style: TextStyle(color: Colors.black54, fontSize: 14),
                      ),
                      const Divider(height: 32),

                      // ================= SECTION 1: JENIS PERJALANAN (RADIO) =================
                      const Text('1. Pilih Jenis Perjalanan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: ['Sekali jalan', 'Pulang-pergi']
                              .map((tipe) => RadioListTile<String>(
                                    title: Text(tipe),
                                    value: tipe,
                                    groupValue: _jenisPerjalanan,
                                    onChanged: (val) {
                                      setState(() {
                                        _jenisPerjalanan = val!;
                                      });
                                    },
                                  ))
                              .toList(),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ================= SECTION 2: RUTE & JADWAL =================
                      const Text('2. Rute & Jadwal Penerbangan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: _kotaAsal,
                        decoration: const InputDecoration(
                          labelText: 'Kota / Bandara Asal (Dari)',
                          prefixIcon: Icon(Icons.flight_takeoff),
                        ),
                        items: _daftarKota.map((kota) => DropdownMenuItem(value: kota, child: Text(kota))).toList(),
                        onChanged: (val) => setState(() => _kotaAsal = val),
                        validator: (val) => val == null ? 'Kota asal wajib dipilih' : null,
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _kotaTujuan,
                        decoration: const InputDecoration(
                          labelText: 'Kota / Bandara Tujuan (Ke)',
                          prefixIcon: Icon(Icons.flight_land),
                        ),
                        items: _daftarKota.map((kota) => DropdownMenuItem(value: kota, child: Text(kota))).toList(),
                        onChanged: (val) => setState(() => _kotaTujuan = val),
                        validator: (val) => val == null ? 'Kota tujuan wajib dipilih' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _tanggalBerangkatController,
                        readOnly: true,
                        onTap: () => _pilihTanggal(context, _tanggalBerangkatController),
                        decoration: const InputDecoration(
                          labelText: 'Tanggal Keberangkatan',
                          prefixIcon: Icon(Icons.calendar_today),
                        ),
                        validator: (val) => val == null || val.isEmpty ? 'Tanggal keberangkatan wajib diisi' : null,
                      ),
                      if (_jenisPerjalanan == 'Pulang-pergi') ...[
                        const SizedBox(height: 12),
                        TextFormField(
                          controller: _tanggalKepulanganController,
                          readOnly: true,
                          onTap: () => _pilihTanggal(context, _tanggalKepulanganController),
                          decoration: const InputDecoration(
                            labelText: 'Tanggal Kepulangan',
                            prefixIcon: Icon(Icons.calendar_month),
                          ),
                          validator: (val) => val == null || val.isEmpty ? 'Tanggal kepulangan wajib diisi' : null,
                        ),
                      ],
                      const SizedBox(height: 20),

                      // ================= SECTION 3: JUMLAH PENUMPANG =================
                      const Text('3. Jumlah Penumpang', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: TextFormField(
                              initialValue: '1',
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(labelText: 'Dewasa (>12th)'),
                              onChanged: (val) => _jumlahDewasa = int.tryParse(val) ?? 1,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextFormField(
                              initialValue: '0',
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(labelText: 'Anak (2-11th)'),
                              onChanged: (val) => _jumlahAnak = int.tryParse(val) ?? 0,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: TextFormField(
                              initialValue: '0',
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(labelText: 'Bayi (<2th)'),
                              onChanged: (val) => _jumlahBayi = int.tryParse(val) ?? 0,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      // ================= SECTION 4: DATA PEMESAN =================
                      const Text('4. Data Pemesan (Contact Person)', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      TextFormField(
                        controller: _namaPemesanController,
                        decoration: const InputDecoration(
                          labelText: 'Nama Lengkap Pemesan',
                          prefixIcon: Icon(Icons.person),
                        ),
                        validator: (val) => val == null || val.trim().isEmpty ? 'Nama pemesan wajib diisi' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _teleponController,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(
                          labelText: 'Nomor Telepon / WhatsApp',
                          prefixIcon: Icon(Icons.phone),
                        ),
                        validator: (val) => val == null || val.trim().isEmpty ? 'Nomor telepon wajib diisi' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        decoration: const InputDecoration(
                          labelText: 'Alamat Email (Pengiriman E-Tiket)',
                          prefixIcon: Icon(Icons.email),
                        ),
                        validator: (val) {
                          if (val == null || val.trim().isEmpty) return 'Email wajib diisi';
                          if (!val.contains('@')) return 'Format email tidak valid';
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),

                      // ================= SECTION 5: DATA PENUMPANG =================
                      const Text('5. Data Penumpang Utama', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: _JenisKelamin,
                        decoration: const InputDecoration(labelText: 'Jenis Kelamin'),
                        items: ['Laki-Laki', 'Perempuan'].map((g) => DropdownMenuItem(value: g, child: Text(g))).toList(),
                        onChanged: (val) => setState(() => _JenisKelamin = val!),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _namaDepanPenumpangController,
                        decoration: const InputDecoration(labelText: 'Nama Depan (First Name)'),
                        validator: (val) => val == null || val.trim().isEmpty ? 'Nama depan wajib diisi' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _namaBelakangPenumpangController,
                        decoration: const InputDecoration(labelText: 'Nama Belakang (Last Name)'),
                        validator: (val) => val == null || val.trim().isEmpty ? 'Nama belakang wajib diisi' : null,
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _nomorIdentitasController,
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText: 'Nomor NIK KTP / Paspor',
                          hintText: 'Minimal 8 digit angka',
                          prefixIcon: Icon(Icons.badge),
                        ),
                        validator: (val) {
                          if (val == null || val.trim().isEmpty) return 'Nomor identitas wajib diisi';
                          if (val.trim().length < 8) return 'Nomor identitas minimal 8 digit';
                          return null;
                        },
                      ),
                      const SizedBox(height: 20),

                      // ================= SECTION 6: PREFERENSI & TAMBAHAN =================
                      const Text('6. Preferensi Penerbangan & Tambahan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: _maskapaiTerpilih,
                        decoration: const InputDecoration(
                          labelText: 'Pilihan Maskapai',
                          prefixIcon: Icon(Icons.airplanemode_active),
                        ),
                        items: _daftarMaskapai.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
                        onChanged: (val) => setState(() => _maskapaiTerpilih = val),
                        validator: (val) => val == null ? 'Pilih salah satu maskapai' : null,
                      ),
                      const SizedBox(height: 12),
                      DropdownButtonFormField<String>(
                        value: _kelasKursi,
                        decoration: const InputDecoration(labelText: 'Kelas Kursi'),
                        items: ['Economy', 'Business', 'First Class']
                            .map((k) => DropdownMenuItem(value: k, child: Text(k)))
                            .toList(),
                        onChanged: (val) => setState(() => _kelasKursi = val!),
                      ),
                      const SizedBox(height: 10),
                      const Text('Fasilitas Tambahan', style: TextStyle(fontWeight: FontWeight.w600)),
                      Container(
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          children: _fasilitasTambahan.keys.map((key) {
                            return CheckboxListTile(
                              title: Text(key),
                              value: _fasilitasTambahan[key],
                              controlAffinity: ListTileControlAffinity.leading,
                              onChanged: (val) => setState(() => _fasilitasTambahan[key] = val ?? false),
                            );
                          }).toList(),
                        ),
                      ),
                      const SizedBox(height: 20),

                      // ================= SECTION 7: PEMBAYARAN =================
                      const Text('7. Metode Pembayaran', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 10),
                      DropdownButtonFormField<String>(
                        value: _metodePembayaran,
                        decoration: const InputDecoration(
                          labelText: 'Pilih Metode Pembayaran',
                          prefixIcon: Icon(Icons.payment),
                        ),
                        items: ['Transfer Bank', 'Virtual Account', 'Kartu Kredit', 'QRIS', 'e-Wallet']
                            .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                            .toList(),
                        onChanged: (val) => setState(() => _metodePembayaran = val!),
                      ),
                      const SizedBox(height: 16),

                      // Syarat & Ketentuan[cite: 19]
                      CheckboxListTile(
                        contentPadding: EdgeInsets.zero,
                        controlAffinity: ListTileControlAffinity.leading,
                        title: const Text(
                          'Saya menyetujui syarat dan ketentuan pemesanan tiket penerbangan.',
                          style: TextStyle(fontSize: 13),
                        ),
                        value: _setujuSyarat,
                        onChanged: (val) => setState(() => _setujuSyarat = val ?? false),
                      ),
                      const SizedBox(height: 24),

                      // Tombol Simpan / Kirim Form
                      SizedBox(
                        width: double.infinity,
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: _prosesPemesanan,
                          icon: const Icon(Icons.send),
                          label: const Text(
                            'Pesan Tiket Sekarang',
                            style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color.fromARGB(255, 83, 0, 108),
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
